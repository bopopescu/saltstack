#!/usr/bin/perl -w
#############################################################################
# logdog.pl
# Written by: Brandon Zehm <caspian@dotconf.net>
#
# License:
#
# logdog.pl (hereafter referred to as "program") is free software;
#   you can redistribute it and/or modify it under the terms of the GNU General
#   Public License as published by the Free Software Foundation; either version
#   2 of the License, or (at your option) any later version.
# Note that when redistributing modified versions of this source code, you
#   must ensure that this disclaimer and the above coder's names are included
#   VERBATIM in the modified code.
#
# Disclaimer:
# This program is provided with no warranty of any kind, either expressed or
#   implied.  It is the responsibility of the user (you) to fully research and
#   comprehend the usage of this program.  As with any tool, it can be misused,
#   either intentionally (you're a vandal) or unintentionally (you're a moron).
#   THE AUTHOR(S) IS(ARE) NOT RESPONSIBLE FOR ANYTHING YOU DO WITH THIS PROGRAM
#   or anything that happens because of your use (or misuse) of this program,
#   including but not limited to anything you, your lawyers, or anyone else
#   can dream up.  And now, a relevant quote directly from the GPL:
#
#                           NO WARRANTY
#
#  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
# FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
# OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
# PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
# OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
# TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
# PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
# REPAIR OR CORRECTION.
#
#   ---
#
# Whee, that was fun, wasn't it?  Now let's all get together and think happy
#   thoughts - and remember, the same class of people who made all the above
#   legal spaghetti necessary are the same ones who are stripping your rights
#   away with DVD CCA, DMCA, stupid software patents, and retarded legal
#   challenges to everything we've come to hold dear about our internet.
#   So enjoy your dwindling "freedom" while you can, because 1984 is coming
#   sooner than you think.  :[
#
#############################################################################
#
# Purpose: To create a program that is capable of monitoring messages passed
#          through syslogd, triggering alerts if needed.
#          
#
# Layout:  Version two of logdog takes a different approach to monitoring
#          than the last version.  This version is designed to listen to 
#          a fifo socket for incoming messages.  Syslogd can log to a fifo
#          socket simply by putting a pipe (|) character before the name 
#          of the file.  So to have syslogd send its messages to /dev/fifo
#          you would simply have an entry in your syslog.conf like this:
#          *.*                                     |/var/log/fifo.logdog
#
# Features:
#       - Monitor syslogd messages for key words and phrases and run system 
#         commands based on content.
#       - HUP signal is intercepted correctly and causes logdog to reload
#         its configuration and refresh all filehandles.
#       - Reads data from syslogd via a FIFO for efficiency and low latency alerts.
#       - Debugging mode with multiple debugging levels (enabled via a 
#         variable at the top of this script or command line arguments)
#         
#
#############################################################################
use strict;
use IO::Socket;



## Global Variable(s)
my %conf = (
    "programName"          => $0,                                ## The name of this program
    "version"              => '2.0-RC5',                         ## The version of this program
    "authorName"           => 'Brandon Zehm',                    ## Author's Name
    "authorEmail"          => 'caspian@dotconf.net',             ## Author's Email Address
    "debug"                => 0,                                 ## Default debug level
    "configurationFile"    => '/etc/logdog.conf',                ## Default configuration file
    "hostname"             => $ENV{'HOSTNAME'},                  ## Used in printmsg() for all output.
    
    ## The following entries are used later in the program
    "mode"                 => '',                                ## Used later by the program
    "logging"              => '',                                ## If this is true the printmsg function prints to the log file
    "nofork"               => 0,                                 ## If set to 1 script will not fork
    
    ## The folling entries get their values from the configuration file
    "fifo"                 => '',
    "logFile"              => '',
    "pidFile"              => '',
    
);

## Variables populated by the configuration file
my %alerts = ();                                                 ## List of alert names, and commands to run when those alerts are called from the monitors section
my @monitors = ();                                               ## List of key words to look for, and alerts to run when those are found
my @ignore = ();                                                 ## List of key words that cause a message to be completly ignored



#############################
##
##      MAIN PROGRAM
##
#############################

## Initialize
initialize();

## All other initialization stuff
processCommandLine();
handleHUP();

## Open fifo
if (openFIFO($conf{'fifo'})) { quit("ERROR => Connecting to fifo [$conf{'fifo'}] returned the error: $!", 1); }









 #######################
##                     ##
##  MAIN PROGRAM LOOP  ##
##                     ##
 #######################


## Become deamon
if ($conf{"mode"} =~ /daemon/i) {
    
    if ( ($conf{'debug'} >= 1) or ($conf{'nofork'}) or (fork() == 0) ) {
        
        ## Write the pidfile (or quit)
        if ($conf{'pidFile'}) {
            if (openPidFile($conf{'pidFile'})) { quit("ERROR => Opening the file [$conf{'pidFile'}] returned the error: $!", 1); }
        }
        
        ## Setup HUP handler function - this will re-read the configuration file, re-open the fifo, log file, etc
        $SIG{'HUP'}   = sub { printmsg("INFO => Received SIGHUP", 0); handleHUP(); };
        
        ## Drop permissions
        ## Something to note is that if handleHUP() is called after permissions are dropped, 
        ## and permissions are not correct for the PID file, conf file, log file, and fifo it 
        ## will likely fail, posibly exiting Logdog.
        $> = $conf{'UID'} if ($conf{'UID'});
        $) = $conf{'GID'} if ($conf{'GID'});
        
        ## Tell the user that we have started successfully
        printmsg("INFO => Daemon mode started successfully", 0);
        
        ## Set the mode to running so that messages get logged rather than printed to the screen
        $conf{"mode"} = "running";
        
        ## Close normal output methods since we won't be needing them in daemon mode
        close STDOUT unless ($conf{"debug"} >= 1);
        close STDERR unless ($conf{"debug"} >= 1);
        
        ## Define a few variables out here to keep CPU usage down
        my ($message, %actions, $alert, $key, $hostname, $numMonitors, $command);
        
        ## The number of monitors (key words to watch for) = 1/2 the size of the array
        $numMonitors = scalar(@monitors);
        
        ## Get the hostname (once to keep CPU usage down)
        $hostname = $ENV{'HOSTNAME'};
        $hostname =~ s/\..*//;
        
        ## Forever
        while (1) {
            
            ## Read a line from the fifo
            $message = <FIFO>;
            chomp $message if ($message);
            
            if ($message) {
                
                ## If the message was forwarded through syslogForwarder.pl strip the
                ## local hostname from the message.
                if ($message =~ /($hostname)(\s+)(REMOTE ENTRY: \[)/io) {
                    $message =~ s/($hostname)(\s+)(REMOTE ENTRY: \[)//io;
                    $message =~ s/([^\s]+)(\])/$1/io;
                }
                
                
                ## Check to see if the message matches one of our monitor phrases
                ## If it does then add the appropriate alert command to a list of alerts to run later.
                for ($key = 0; $key < $numMonitors; $key = $key + 2) {
                    if ($message =~ /$monitors[$key]/i) {
                        foreach $alert ((split(/\s*,\s*/, $monitors[$key+1]))) {
                            ## Make sure if "stop" is used, it's lower case.
                            if ($alert =~ /^stop$/i) { $alert = "stop"; }
                            ## Add the current alert
                            $actions{$alert} = 1;
                        }
                        if ($actions{'stop'}) {
                            delete $actions{'stop'};  ## Don't try to run "stop"
                            last;
                        }
                    }
                }
                
                
                ## Check to see if the message matches one of the ignore entries
                ## If it does, then empty the list of alerts to run
                if (scalar(%actions)) {
                    foreach $key (@ignore) {
                        if ($message =~ /$key/i) {
                            %actions = ();
                            last;
                        }
                    }
                }
                
                
                ## Run appropriate alert commands if needed
                if (scalar(%actions)) {
                    foreach $key (keys(%actions)) {
                        $command = $alerts{$key};
                        if ($command) {
                            
                            ## Backslash several Bash special characters (will this cause problems with systems that run ksh or csh?)
                            $message =~ s/([\`\"\$])/\\$1/g;
                            
                            ## Substitute MESSAGE with the current message
                            $command =~ s/MESSAGE/$message/g;
                            
                            ## Log what we're about to do
                            printmsg("INFO => Running the alert entry [$key] with command [$alerts{$key}] and message [$message]", 0);
                            
                            ## Run the system command
                            system(qq{$command &});
                        }
                        else {
                            printmsg("WARNING => I was about to execute the alert [$key], but it does not appear to have a command associated with it!  Logdog will continue to run, but you should fix and reload the configuration file!", 0);
                        }
                    }
                }
                
                ## Cleanup variables
                %actions = ();
                $message = $alert = $key = $command = "";
            }
        }
    }
}




## Quit (should never get here)
quit("",0);
































###############################################################################################
## Function:    help ()
##
## Description: For all those newbies ;) 
##              Prints a help message and exits the program.
## 
###############################################################################################
sub help {
print <<EOM;

$conf{'programName'}-$conf{'version'} by $conf{'authorName'} <$conf{'authorEmail'}>

Usage:  $conf{'programName'} -d [options]
  
  Required:
    -d,--daemon                   become a daemon
  
  Optional:
    -c <file>,--config=<file>     configuration file [$conf{'configurationFile'}]
    -f <file>,--fifo=<file>       fifo to receive messages on
    -n                            no fork (disable forking at startup)
    -v                            verbosity - use multiple times for greater effect
  
EOM
exit(1);
}










###############################################################################################
##  Function: initialize ()
##  
##  Does all the script startup jibberish.
##  
###############################################################################################
sub initialize {
    
    ## Set STDOUT to flush immediatly after each print  
    $| = 1;
    
    ## Intercept signals
    $SIG{'QUIT'}  = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
    $SIG{'INT'}   = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
    $SIG{'KILL'}  = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
    $SIG{'TERM'}  = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
    $SIG{'HUP'}   = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
    $SIG{'ALRM'}  = sub { quit("WARNING => EXITING: Received SIG$_[0]", 1); };
  
    ## Fixup $conf{'programName'}
    $conf{'programName'} =~ s/(.)*[\/,\\]//;
    $0 = $conf{'programName'} . " " . join(" ", @ARGV);
    
    ## Fixup $conf{'hostname'}
    if ($conf{'hostname'}) {
        $conf{'hostname'} = $conf{'hostname'};
        $conf{'hostname'} =~ s/\..*$//;
    }
    else {
        $conf{'hostname'} = "unknown";
    }
  
    return(0);
}









###############################################################################################
##  Function: processCommandLine ()
##  
##  Processes command line storing important data in global var %conf
##  
###############################################################################################
sub processCommandLine {
    
    
    ############################
    ##  Process command line  ##
    ############################
    
    my @ARGS = @ARGV;
    my $numargv = @ARGS;
    help() unless ($numargv);
    my $counter = 0;
    for ($counter = 0; $counter < $numargv; $counter++) {
    
        if ($ARGS[$counter] =~ /^-d$|^--daemon$/i) {         ## Daemon ##
            $conf{'mode'} = "daemon";
        }
        
        elsif ($ARGS[$counter] =~ s/^--config=//i) {         ## Config File ##
            $conf{'configurationFile'} = $';
        }
        
        elsif ($ARGS[$counter] =~ /^-c$/i) {                 ## Config File ##
            $counter++;
            $conf{'configurationFile'} = $ARGS[$counter];
        }
        
        elsif ($ARGS[$counter] =~ s/^--fifo=//i) {           ## FIFO Socket ##
            $conf{'fifo'} = $';
        }
        
        elsif ($ARGS[$counter] =~ /^-f$/i) {                 ## FIFO Socket ##
            $counter++;
            $conf{'fifo'} = $ARGS[$counter];
        }
        
        elsif ($ARGS[$counter] =~ /^-n$/) {                  ## No Fork ##
            $conf{'nofork'} = 1;
        }
        
        elsif ($ARGS[$counter] =~ s/^-v+//i) {               ## Verbosity ##
            $conf{'debug'} += (length($&) - 1);
        }
        
        elsif ($ARGS[$counter] =~ /^-h$|help/i) {            ## Help ##
            help();
        }
        
        else {
            quit("ERROR => The command line argument \"$ARGS[$counter]\" is invalid! Try --help.", 16);
        }
        
    }
    
    ## Print help if we're not becoming a daemon.
    if (!$conf{'mode'}) {
        printmsg("WARNING => The -d parameter must be passed to become a daemon.", 0);
    }
    
    ###################################################
    ##  Verify required variables are set correctly  ##
    ###################################################
    my @required = (
                      'configurationFile',
                      'mode',
    );
    foreach (@required) {
        if (!$conf{$_}) {
            quit("ERROR => The value [$_] was not set after parsing command line arguments!", 1);
        }
    }
    
    return(1);
}



















###############################################################################################
## FUNCTION:    
##   readConfigurationFile ( string $filename )
## 
## 
## DESCRIPTION: 
##   Reads the file $filename, and stores information from the file into 
##   the global array $conf, and a few other global arrays.  This version
##   of this function is specifically modified to support logdog's configuration
##   file.
##
## Example: 
##   readConfigurationFile("/etc/configuration.conf");
##
###############################################################################################
sub readConfigurationFile {
    
    ## Get incoming variables
    my %incoming = ();
    (
      $incoming{'confFile'},
    ) = @_;
    $incoming{'section'} = "";
    
    ## Open the file
    open(CONFFILE, $incoming{'confFile'}) or quit("ERROR => While opening the configuration file [$incoming{'confFile'}].  The error was: $!\n", 1);
    while (<CONFFILE>) {  ## FOR EACH LINE
        my $line = $_;
        chomp $line;                    ## Remove line ending characters
        $line =~ s/(^|[^\\])\#.*$//og;  ## Remove # comments - unless backslash escaped
        $line =~ s/\\\#/\#/og;          ## Replace '\#' with '#' 
        $line =~ s/\/\/.*$//og;         ## Remove // comments
        $line =~ s/^\s+//o;             ## Remove leading white space
        $line =~ s/\s+$//o;             ## Remove ending white space
        
        ## Get the section
        if ($line =~ /section/i) {
            $incoming{'section'} = (split(/:/, $line))[1];
            $incoming{'section'} =~ s/^\s*//;     ## Remove leading white space
            $incoming{'section'} =~ s/\s*$//;     ## Remove ending white space
            $line = "";
        } 
        
        
        if ($line ne "") {
            
            ## Assign data for section: general
            if ($incoming{'section'} =~ /general/i) {
                $conf{(split(/\s*=>\s*/, $line))[0]} = (split(/\s*=>\s*/, $line))[1] unless ($conf{(split(/\s*=>\s*/, $line))[0]});
            }
            
            ## Assign data for section: alerts
            if ($incoming{'section'} =~ /alerts/i) {
                my ($key, $value);
                ($key, $value) = split(/\s*=>\s*/, $line);
                ## Assign the value unless the entry already exists or the value is null
                $alerts{$key} = $value unless ( ($alerts{$key}) or (!$value) );
            }
            
            ## Assign data for section: monitors
            if ($incoming{'section'} =~ /monitors/i) {
                my ($key, $value);
                ($key, $value) = split(/\s*=>\s*/, $line);
                if ($key and $value) {
                    my $entry = (scalar(@monitors));
                    $monitors[$entry]     = $key;
                    $monitors[$entry + 1] = $value;
                }
                else {
                    printmsg("WARNING => The line [$line] in the [$incoming{'section'}] section does not appear valid, ignoring it.", 0);
                }
            }
            
            ## Assign data for section: ignore
            if ($incoming{'section'} =~ /ignore/i) {
                push(@ignore, $line);
            }
            
        }
    }
    close(CONFFILE);
    
    ## Verify that all alerts have a command associated
    foreach my $key (keys(%alerts))   { if (!$alerts{$key}) { printmsg("WARNING => The alert definition [$key] does not have any command associated with it.   Logdog will continue to run, but you should fix and reload the configuration file!", 0); } }
    
    ## Verify that all monitors have valid alerts
    for (my $a = 0; $a < scalar(@monitors); $a = $a + 2) {
        foreach my $alert (split(/\s*,\s*/, $monitors[$a + 1])) {
            unless ($alert =~ /stop/i) {
                if (!$alerts{$alert}) {
                    printmsg ("WARNING => The monitor [" . $monitors[$a] . "] references an alert [" . $monitors[$a+1] . "] that does not exsist! Logdog will continue to run, but you should fix and reload the configuration file!", 0);
                }
            }
        }
    }
    
    ## If a UID or GID was specified then convert it to the numeric value
    if ($conf{'UID'}) { if ($conf{'UID'} =~ /\w/) {
        $conf{'UID'} = (getpwnam($conf{'UID'}))[2];
    }                 }
    if ($conf{'GID'}) { if ($conf{'GID'} =~ /\w/) {
        $conf{'GID'} = (getgrnam($conf{'GID'}))[2];
    }                 }
    
    ## Debugging: Show the current configuration
    printmsg ("DEBUG => *** Configuration ***", 3); foreach my $key (keys(%conf))     { printmsg ("DEBUG => Key: $key =>\t Value: $conf{$key}", 3) if ($key and $conf{$key}); }
    printmsg ("DEBUG => *** Alerts ***", 3);        foreach my $key (keys(%alerts))   { printmsg ("DEBUG => Key: $key\t Value: $alerts{$key}", 3) if ($key and $alerts{$key}); }
    printmsg ("DEBUG => *** Monitor List ***", 3);  for (my $a = 0; $a < scalar(@monitors); $a = $a + 2) { printmsg ("DEBUG => Key: $monitors[$a]\t Value: $monitors[$a+1]", 3) if ($monitors[$a] and $monitors[$a+1]); }
    printmsg ("DEBUG => *** Ignore List ***", 3);   foreach my $key (@ignore)         { printmsg ("DEBUG => Key: $key", 3) if ($key); }
    
    return(1);
}


















###############################################################################################
# FUNCTION: handleHUP()
# 
# Handles HUP signals:
#  - Re-reads the configuration file
#  - Re-parses the command line
#  - Logs a message to the log file
#  - Closes and opens the log file 
#  - Drops EUID and EGID if needed
#
###############################################################################################
sub handleHUP  {
    
    printmsg("INFO => Reloading config and refreshing all file handles", 0);
    
    
    #####################################################
    ##  Reset some variables that should be refreshed  ##
    #####################################################
    %alerts = ();
    @monitors = ();
    @ignore = ();
    $conf{'logFile'} = '';
    
    
    ######################################
    ##  Re-read the configuration file  ##
    ######################################
    readConfigurationFile($conf{'configurationFile'});
    
    
    #######################################################
    ##  Re-parse the command line - it takes precedence  ##
    #######################################################
    $conf{'debug'} = 0;  ## Reset this here because otherwise debug in readConfig doesn't work
    processCommandLine();
    
    
    ###################################
    ##  Close and open the log file  ##
    ###################################
    if ($conf{'logFile'}) {
        if ($conf{'logging'}) {
            $conf{'logging'} = 0;
            close LOGFILE;
        }
        if (openLogFile($conf{'logFile'})) { quit("ERROR => Opening the file [$conf{'logFile'}] returned the error: $!", 1); }
    }
    
    
    ## Check the PID file - if another logdog.pl process is running with the same pid file
    ## we want to quit so we don't end up with multiple instances of the same script running.
    if ($conf{'pidFile'}) {
        if (checkPidFile($conf{'pidFile'}) != 0) {
            quit("ERROR => Another Logdog process seems to already be running.  More than one instance of Logdog may not be run without different PID files.", 1);
        }
    }
    
    
    ## Go back to the normal routine
    return(1);
}














###############################################################################################
##  Function:    printmsg (string $message, int $level)
##
##  Description: Handles all messages - 
##               Depending on the state of the program it will log
##               messages to a log file, print them to STDOUT or both.
##               
##
##  Input:       $message          A message to be printed, logged, etc.
##               $level            The debug level of the message. If not defined 0
##                                 will be assumed.  0 is considered a normal message, 
##                                 1 and higher is considered a debug message.
##  
##  Output:      Prints to STDOUT, to LOGFILE, both, or none depending 
##               on the state of the program and the debug level specified.
##  
##  Example:     printmsg("ERROR => The file could not be opened!", 0);
###############################################################################################
sub printmsg {
    ## Assign incoming parameters to variables
    my ( $message, $level ) = @_;
    
    ## Make sure input is sane
    $level = 0 if (!defined($level));
    
    ## Continue only if the debug level of the program is >= message debug level.
    if ($conf{'debug'} >= $level) {
        
        ## Get the date in the format: Dec  3 11:14:04
        my ($sec, $min, $hour, $mday, $mon) = localtime();
        $mon = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')[$mon];
        my $date = sprintf("%s %02d %02d:%02d:%02d", $mon, $mday, $hour, $min, $sec);
    
        ## Print to STDOUT always if debugging is enabled, or if the mode is NOT "running".
        if ( ($conf{'debug'} >= 1) or ($conf{'mode'} ne "running") ) {
            print "$date $conf{'hostname'} $conf{'programName'}\[$$\]: $message\n";
        }
        
        ## Print to the log file if $conf{'logging'} is true
        if ($conf{'logging'}) {
            print LOGFILE "$date $conf{'hostname'} $conf{'programName'}\[$$\]: $message\n";
        }
        
    }
    
    ## Return 0 errors
    return(0);
}












###############################################################################################
## FUNCTION:    
##   openLogFile ( $filename )
## 
## 
## DESCRIPTION: 
##   Opens the file $filename and attaches it to the filehandle "LOGFILE".  Returns 0 on success
##   and non-zero on failure.  Error codes are listed below, and the error message gets set in
##   global variable $!.
##   
##   
## Example: 
##   openFile ("/var/log/scanAlert.log");
##
###############################################################################################
sub openLogFile {
    ## Get the incoming filename
    my $filename = $_[0];
    
    ## Make sure our file exists, and if the file doesn't exist then create it
    if ( ! -f $filename ) {
        printmsg("NOTICE => The file [$filename] does not exist.  Creating it now with mode [0600].", 0);
        open (LOGFILE, ">>$filename");
        close LOGFILE;
        chmod (0600, $filename);
    }
    
    ## Now open the file and attach it to a filehandle
    open (LOGFILE,">>$filename") or return (1);
    
    ## Put the file into non-buffering mode
    select LOGFILE;
    $| = 1;
    select STDOUT;
    
    ## Tell the rest of the program that we can log now
    $conf{'logging'} = "yes";
    
    ## Return success
    return(0);
}












###############################################################################################
## FUNCTION:    
##   openFIFO ( $filename )
## 
## 
## DESCRIPTION: 
##   Opens the fifo $filename for reading and attaches it to the filehandle "FIFO".  Returns 0 on success
##   and non-zero on failure.  Error codes are listed below, and the error message gets set in
##   global variable $!. 
##   
##
## Example: 
##   openFIFO ("/var/log/fifo.logdog");
##
###############################################################################################
sub openFIFO {
    ## Get the incoming filename
    my $filename = $_[0];
    
    ## Make sure our fifo exists, and if the fifo doesn't exist then create it
    if ( ! -p $filename ) {
        quit("ERROR => FIFO does not exist or is not a FIFO at [$conf{'fifo'}]\nDid you forget to create it and configure syslogd to log to it?\n", 1);
    }
    
    ## Open the FIFO socket we're supposed to listen to and attach it to a filehandle
    
    $SIG{'ALRM'}  = sub { quit("ERROR => Timeout while opening FIFO [$conf{'fifo'}].  Possible solution: configure syslogd to log to this FIFO and restart syslogd.", 1); };
    alarm(10);
    open (FIFO,"< $filename") or return(1);
    alarm(0);
    
    ## Return success
    return(0);
}











###############################################################################################
## FUNCTION:
##   openPidFile ($pidfilename )
##
##
## DESCRIPTION:
##   Opens the file $pidfilename and writes the pid in there
##
## Example:
##   openPidFile ("/var/run/bla.pid");
##
###############################################################################################
sub openPidFile {
    ## Get the pidfile name
    my $pidfilename = $_[0];

    ## If $pidfilename is empty then the user has not specified a PID file and it is
    ## safe for us to return 0 and continue running.
    if (!$pidfilename) {
        printmsg("DEBUG => openPidFile() - required parameter missing.", 2);
        return(1);
    }
    
    ## Open the PID file
    if (! open (PIDFILE, ">$pidfilename")) { return 1; }
    
    ## Put the pid in the file
    print PIDFILE "$$\n";
    close PIDFILE;
    if (! chmod (0600, $pidfilename)) { return 2; }
    
    ## Return success (0 errors)
    return(0);
}












###############################################################################################
## FUNCTION:
##   checkPidFile ($pidfilename )
##
##
## DESCRIPTION:
##   Returns an error (a number >= 1) if the pid file exists, and the pid specified in it references
##   a currently running Logdog.pl process.
##   Otherwise it returns 0.
##
## Example:
##   checkPidFile ("/var/run/bla.pid");
##
###############################################################################################
sub checkPidFile {
    ## Get the pidfile name
    my $pidfilename = $_[0];
    
    printmsg("DEBUG => checkPidFile() - checking to see if it's safe for us to continue running.", 1);
    
    ## If $pidfilename is empty then the user has not specified a PID file and it is
    ## safe for us to return 0 and continue running.
    if (!$pidfilename) {
        printmsg("DEBUG => checkPidFile() - returning 0 since the pid file was empty (not specified.)", 2);
        return(0);
    }
    
    ## Check to see if the file exists
    if (! -e $pidfilename) {
        ## Return success if the PID file doesn't exist.
        printmsg("DEBUG => checkPidFile() - returning 0 since the pid file specified doesn't exist.", 2);
        return(0);
    }
    
    ## Open the PID file.
    if (! open(PIDFILE, $pidfilename)) {
        ## Return an error if it exists but we couldn't open it.
        printmsg("DEBUG => checkPidFile() - returning 1 since I couldn't open the pid file.", 2);
        return(1);
    }
    
    ## Read the PID from the file into $pid
    my $pid = <PIDFILE>;
    chomp $pid;
    close PIDFILE;
    
    ## If the PID file contains our PID it's safe to continue running.
    if ($pid == $$) {
        printmsg("DEBUG => checkPidFile() - returning 0 since the PID file contains my PID.", 2);
        return(0);
    }
    
    ## Check to see if that process is running
    if (! -d "/proc/$pid") {
        ## Return success if the PID is not running
        printmsg("DEBUG => checkPidFile() - returning 0 since the PID specified in the pid file is not running.", 2);
        return(0);
    }
    
    ## Open the PID cmdline file so we can get the process name for the running PID.
    if (! open(PIDFILE, "/proc/$pid/cmdline")) {
        ## Return an error if it exists but we couldn't open it.
        printmsg("DEBUG => checkPidFile() - returning 2 because for some reason I wasn't able to open the file: /proc/$pid/cmdline", 2);
        return(2);
    }
    
    ## proc/xxx/cmdline can be split by \0 to get the different parts
    my $pidname = <PIDFILE>;
    $pidname =~ s/\0/ /;
    
    if ($pidname =~ /logdog/io) {
        printmsg("DEBUG => checkPidFile() - returning 3 the process referenced in the pid file [$pidname] is another Logdog process.", 2);
        return(3);
    }
    
    ## If we get to here it's safe for us to start
    printmsg("DEBUG => checkPidFile() - returning 0 since the process recerenced in the pid file [$pidname] is not another Logdog process.", 2);
    return(0);
}











###############################################################################################
## FUNCTION:    
##   syslog (string $socketName, int $priority, int $facility, string $message)
## 
## 
## DESCRIPTION: 
##   Connects to the socket $socketName, and sends it a syslog formatted message.  
##   i.e. it syslog's $message with the priority and facility specified.
##   Returns 0 on success, non-zero on error.  If an error occurs the error message
##   is stored in the global variable $conf{'error'}.
##
## Example: 
##   syslog("/dev/log", 6, 1, "Test syslog message");
##
##
## Priorities (on a Linux system)
##   LOG_EMERG       0       system is unusable
##   LOG_ALERT       1       action must be taken immediately
##   LOG_CRIT        2       critical conditions
##   LOG_ERR         3       error conditions
##   LOG_WARNING     4       warning conditions
##   LOG_NOTICE      5       normal but significant condition
##   LOG_INFO        6       informational
##   LOG_DEBUG       7       debug-level messages
##
##
## Facilities (on a Linux system)
##   LOG_KERN        0       kernel messages
##   LOG_USER        1       random user-level messages
##   LOG_MAIL        2       mail system
##   LOG_DAEMON      3       system daemons
##   LOG_AUTH        4       security/authorization messages
##   LOG_SYSLOG      5       messages generated internally by syslogd
##   LOG_LPR         6       line printer subsystem
##   LOG_NEWS        7       network news subsystem
##   LOG_UUCP        8       UUCP subsystem
##   LOG_CRON        9       clock daemon
##   LOG_AUTHPRIV    10      security/authorization messages (private)
##   LOG_FTP         11      ftp daemon
##   LOG_LOCAL0      16      reserved for local use
##   LOG_LOCAL1      17      reserved for local use
##   LOG_LOCAL2      18      reserved for local use
##   LOG_LOCAL3      19      reserved for local use
##   LOG_LOCAL4      20      reserved for local use
##   LOG_LOCAL5      21      reserved for local use
##   LOG_LOCAL6      22      reserved for local use
##   LOG_LOCAL7      23      reserved for local use
##
## v1.0 - 12/04/2002
###############################################################################################
sub syslog {
    
    ## Get incoming variables
    my %incoming = ();
    (
      $incoming{'socketName'},
      $incoming{'priority'},
      $incoming{'facility'},
      $incoming{'message'},
    ) = @_;
    
    ## Set defaults if some variables are not defined
    $incoming{'socketName'}  = "/dev/log"         if (!defined($incoming{'socketName'}));
    $incoming{'priority'}    = 6                  if (!defined($incoming{'priority'}));
    $incoming{'facility'}    = 1                  if (!defined($incoming{'facility'}));
    $incoming{'message'}     = "Default Message"  if (!defined($incoming{'message'}));
    
    ## Bit-shift the facility (black magic)
    $incoming{'facility'} = ($incoming{'facility'}<<3);
    
    ## Make sure values are sane (more black magic)
    $incoming{'priority'} = $incoming{'priority'} & 0x07;
    $incoming{'facility'} = $incoming{'facility'} & 0x3f8;
    
    ## Generate syslog value for the priority and facility
    $incoming{'value'} = ($incoming{'priority'} + $incoming{'facility'});
    
    
    ## Debuging
    printmsg("DEBUG => syslog(): Pri: $incoming{'priority'}  Fac: $incoming{'facility'}  Sum: $incoming{'value'}", 3);
    printmsg("DEBUG => syslog(): Syslogging the message [$incoming{'message'}]", 1);
    
    if (! -S $incoming{'socketName'}) {
        $conf{'error'} = "OS-ERROR - The specified syslog socket [$incoming{'socketName'}] either does not exist or is not a socket.";
        return(1);
    }
    
    ## Open a UNIX socket in dgram mode with udp protocol. 
    socket(SOCKET, PF_UNIX, SOCK_DGRAM, 0) or do { 
        $conf{'error'} = "syslog() - OS-ERROR - $!";
        return(2);
    };
    
    ## Connect our socket to SOCKET
    connect(SOCKET, sockaddr_un ($incoming{'socketName'})) or do {
        $conf{'error'} = "syslog() - OS-ERROR - $!";
        return(3);
    };
    
    ## Sending the message to the syslog socket
    print SOCKET "<$incoming{'value'}>$incoming{'message'}" or do {
        $conf{'error'} = "syslog() - OS-ERROR - $!";
        return(4);
    };
    
    ## Close the socket
    close SOCKET;
    
    ## Return success
    return(0);
}











##############################################################################
##  Function:    quit (string $message, int $errorLevel)
##  
##  Description: Exits the program, optionally printing $message 
##               It returns an exit error level of $errorLevel to the system.  
##               0 means no errors, and is assumed if empty.
##
##  Example:     quit("INFO => Exiting program normally", 0);
##############################################################################
sub quit {
    my %incoming = ();
    (
      $incoming{'message'},
      $incoming{'errorLevel'}
    ) = @_;
    $incoming{'errorLevel'} = 0 if (!defined($incoming{'errorLevel'}));
    
    ## Delete the PID file if we need to
    if (checkPidFile($conf{'pidFile'}) == 0) {
        unlink($conf{'pidFile'}) if (-e $conf{'pidFile'});
    }
    
    ## Print and syslog the exit message
    if ($incoming{'message'}) { 
        printmsg($incoming{'message'}, 0);
        syslog("/dev/log", 4, 3, "$conf{'programName'}\[$$\]: $incoming{'message'}");
    }
    
    ## Exit
    exit($incoming{'errorLevel'});
}




