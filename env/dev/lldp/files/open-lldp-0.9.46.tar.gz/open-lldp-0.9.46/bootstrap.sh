#! /bin/sh -e
libtoolize
exec autoreconf --install -s
