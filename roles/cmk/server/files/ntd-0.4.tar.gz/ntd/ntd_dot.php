<?
if ($wantdot!=0) {
  $headstr="digraph structs {\nnode [shape=Mrecord];\nmindist=0.3;\noverlap=false;\n";

  //iterate hosts
  $hoststr="";
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    $sysservices=(int)$data[$hostip]['sysservices'][0];
    $physdescr=$data[$hostip]['physdescr'][0];
    $physdescr=str_replace('"',"'",$physdescr);
    $physdescr=str_replace(',',"\\n",$physdescr);
    $physdescr=str_replace('\\n ',"\\n",$physdescr);
    //$physdescr=preg_replace("/\W/","\n",$physdescr);

    if ($sysservices==78) {$hosttype="router";$color="lightpink";}
    elseif (($sysservices>0) && ($sysservices<10)) {$hosttype="switch"; $color="lightblue";}
    else {$hosttype="otherhost";$color="grey";}

    $hostip2=str_replace('.',"_",trim($hostip));
    $hoststr.= "\"host_$hostip2\" [fontsize=10 color=$color label=\"{".' '.$hostip.'\n'.$physdescr.'| ';

    $count=0;
    if (array_key_exists('ifindex2portname',$data[$hostip]) && is_array($data[$hostip]['ifindex2portname'])) 
      foreach ($data[$hostip]['ifindex2portname'] as $ifindex=>$portname) { //interface
	$portname=str_replace('"',"",$portname);
	if (array_key_exists('ifindex2vlan',$data[$hostip]))
	  $vlan=$data[$hostip]['ifindex2vlan'][$ifindex];
	else $vlan="";
	//connect to: macs, ips of macs
	if (strlen($vlan)) $vlan2="(VLAN$vlan)"; else $vlan2="";
	//print struct port
	$hoststr.= "<$ifindex> $portname $vlan2";
	  $hoststr.="|";
	$count++;
      }
      $hoststr=substr($hoststr,0,-1); //remove trailing "|" 
    $hoststr.=" }\"];\n\n";
  }

  $hoststr2="";
  //now print other host nodes
  foreach ($mac2ips as $mac=>$iparr) { 
    //find if we already printed this mac's ip
    $iplist="";
    for ($cont=0,$i=0;$i<count($iparr);$i++) { //iterate ips of mac
      $ip=$iparr[$i];
      if (array_key_exists($ip,$data)) {
	$cont++; //ip belongs to a top-node (found from cdp)
      }
      $iplist.="$ip ";
    }
    if ($cont) 
      continue;

    $mac2=str_replace(' ',"_",trim($mac));
    $mac3=str_replace(' ',":",trim($mac));
    $iplist=str_replace(' ',"\\n",trim($iplist));

    $brand="";
    if ($wantbrand) 
      $brand=brandofmac2($mac); //find manufacturer names from MACs
    $brand=str_replace(' ',"_",trim($brand));
    $brand=str_replace('.',"",$brand);
    $brand=str_replace(',_',"_",$brand);
    if (strlen($brand)) $brand='\n'.$brand;
    $hoststr2.= "\"host_$mac2\" [fontsize=10 label=\"<$mac2> $mac3\\n$iplist$brand\"];\n";
  }


  /*now define node connections*/
  $connstr="";
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    $cdpedges="";
    $macstr="";

    if ($hostip=="0.0.0.0") continue;
    $hostip2=str_replace('.',"_",trim($hostip));

    if (array_key_exists('cdpaddress',$data[$hostip]) && is_array($data[$hostip]['cdpaddress'] )) 
      foreach ($data[$hostip]['cdpaddress'] as $i=>$cdpaddress) { 
	$cdpdeviceport=$data[$hostip]['cdpdeviceport'][$i];
	$cdpdeviceport=trim(str_replace('"',"",$cdpdeviceport));
	$cdpaddress2=str_replace('.',"_",trim($cdpaddress));
	$cdplocalifindex=$data[$hostip]['cdplocalifindex'][$i];
	if (strlen($cdplocalifindex)) {
	  //$cdpdeviceport=str_replace("GigabitEthernet","Gi",$cdpdeviceport); $cdpdeviceport=str_replace("FastEthernet","Fa",$cdpdeviceport);
	  //$intname=array_search($cdpdeviceport,$data[$cdpaddress]['ifindex2portname']);
	  $x=array_search($hostip,$data[$cdpaddress]['cdpaddress']);
	  $intname=$data[$cdpaddress]['cdplocalifindex'][$x];
	  if (strlen($intname))
	    $target=":$intname";
	  else $target="";
	    $cdpedges.= "\"host_$hostip2\":$cdplocalifindex -> ".
	              "\"host_$cdpaddress2\"$target [fontsize=9 color=red style=dashed label=\"Goes to $cdpaddress\\n on port:($cdpdeviceport)\"];\n";
	}

      }

    //iterate interface -> mac address table
    if (array_key_exists('ifindex2mac',$data[$hostip]) && is_array($data[$hostip]['ifindex2mac'] ))
      foreach($data[$hostip]['ifindex2mac'] as $ifindex=>$macarray) { //multiple macs per interface
	$macstr1="";
	if (in_array($ifindex,$data[$hostip]['cdplocalifindex'])) { //port connecting switches
	  continue;
	}

	//if multiple macs on a port, make the links only if target is not another known switch
	for ($e=0,$i=0;$i<count($macarray);$i++) { //iterate macs of interface
	  $mac=$macarray[$i];
	  $mac2=str_replace(' ',"_",trim($mac));
	  $h=(float)rand( 0  , 100  )/100.0; //for hsv
	  if (strlen($ifindex))
	    $macstr1.= "\"host_$hostip2\":$ifindex -> \"host_$mac2\" [color=\"$h 1.000 1.000\"];\n";
	}//macs

	$macstr.= $macstr1;

      }//foreach

    $connstr.=$cdpedges;
    $connstr.=$macstr;
    #echo $cdpedges;
    #echo $macstr;
  }

  $tailstr= "}\n";


  echo "<br>Calling dot...<br>\n";
  if(($fp = fopen("x.dot",'w')) === FALSE)
    die("Failed to open x.dot for writing:$php_errormsg!");
  fwrite($fp,$headstr);
  fwrite($fp,$hoststr);
  fwrite($fp,$hoststr2);
  fwrite($fp,$connstr);
  fwrite($fp,$tailstr);
  fclose($fp);
  //$cmd="dot x.dot -Tpng>x.png";
  //pack unconnected nodes
  //$cmd="ccomps -x x.dot |dot|gvpack|neato -Tpng -n2 -s >x.png 2>dot.err";

  /* ******** PNG ********/
  $cmd="ccomps -x x.dot |$graphfilter|gvpack|neato -Tpng -n2 -s >res-ntd.png 2>dot.err";
  file_put_contents("dot.cmd", $cmd);
  echo "Calling $cmd";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $x=trim(fgets($pfp,1024));
  if (strlen($x)) 
    echo "\nDot reports: $x\n";
  fclose($pfp);

  /* ******** SVG ********/
  $cmd="ccomps -x x.dot |$graphfilter|gvpack|neato -Tsvg -n2 -s >res-ntd.svg 2>dotsvg.err";
  echo "Calling $cmd";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $x=trim(fgets($pfp,1024));
  if (strlen($x)) 
    echo "\nDot reports: $x\n";
  fclose($pfp);
} //wantdot

?>
