<?
if ($wantdot!=0) {
  $headstr="digraph structs {\nrankdir = LR;\noverlap=false;\n";

  $macnodes=array(); //filled with macs while they are printed, to avoid redefining them
  $mac2vlan=array();

  //create mac2vlan table from all mac2vlan of switches
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    if (is_array($data[$hostip]['mac2vlan']))
      foreach ($data[$hostip]['mac2vlan'] as $mac=>$vlan) { /* foreach mac */
	if (!empty($vlan))  //same mac exists in multiple switch mac2vlan tables, but as null
	  $mac2vlan[$mac]=$vlan;
      }
  }


  //iterate hosts
  $hoststr="";
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    $sysservices=(int)$data[$hostip]['sysservices'][0];
    $physdescr=$data[$hostip]['physdescr'][0];
    $physdescr=str_replace('"',"'",$physdescr);
    $physdescr=str_replace(',',"\\n",$physdescr);
    $physdescr=str_replace('\\n ',"\\n",$physdescr);
    //$physdescr=preg_replace("/\W/","\n",$physdescr);

    if ($sysservices==78) {$hosttype="router";$color="lightpink";}
    elseif (($sysservices>0) && ($sysservices<10)) {$hosttype="switch"; $color="lightblue";}
    else {$hosttype="otherhost";$color="grey";}

    $hostip2=str_replace('.',"_",trim($hostip));
    $hoststr.= "\"host_$hostip2\" [fontsize=10 shape=box color=$color label=\"".' '.$hostip.'\n'.$physdescr.' ';

    $count=0;
    $hoststr.="\"];\n\n";
  }

  $hoststr2="";
  //now print other host nodes
  foreach ($mac2ips as $mac=>$iparr) { 
    array_push($macnodes,$mac);
    //find if we already printed this mac's ip
    $iplist="";
    for ($cont=0,$i=0;$i<count($iparr);$i++) { //iterate ips of mac
      $ip=$iparr[$i];
      if (array_key_exists($ip,$data)) {
	$cont++; //ip belongs to a top-node (found from cdp)
      }
      $iplist.="$ip ";
    }
    if ($cont) 
      continue;

    $mac2=str_replace(' ',"_",trim($mac));
    $mac3=str_replace(' ',":",trim($mac));
    $iplist=str_replace(' ',"\\n",trim($iplist));

    $brand="";
    if ($wantbrand) 
      $brand=brandofmac2($mac); //find manufacturer names from MACs
    $brand=str_replace(' ',"_",trim($brand));
    $brand=str_replace('.',"",$brand);
    $brand=str_replace(',_',"_",$brand);
    $vlan=$mac2vlan[$mac];
    if (strlen($brand)) $brand='\n'.$brand;
    $hoststr2.= "\"host_$mac2\" [fontsize=10 label=\"$brand\\n$iplist\\n$mac3\\nVLAN:$vlan\"];\n";
  }

  $hoststr3="\n";
  //mac2ips are MACs known to the router. Some devices never go through the router, thus are not in this table. Print also those.
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    if (is_array($data[$hostip]['mac2vlan']))
    foreach ($data[$hostip]['mac2vlan'] as $mac=>$vlan) { /* foreach mac */
      $mac2vlan[$mac]=$vlan;
      if (!in_array($mac,$macnodes)) { 
	if ($wantbrand) 
	  $brand=brandofmac2($mac); //find manufacturer names from MACs
	$mac2=str_replace(' ',"_",trim($mac));
	$mac3=str_replace(' ',":",trim($mac));
	$hoststr3.="\"host_$mac2\" [fontsize=10 label=\"$brand\\n$mac3\\nvlan:$vlan\"];\n";
	array_push($macnodes,$mac);
      }
    }
  }



  /*now define node connections*/
  $connstr="";
  foreach ($data as $hostip=>$hostdata) { /* foreach host */
    $cdpedges="";
    $macstr="";

    if ($hostip=="0.0.0.0") continue;
    $hostip2=str_replace('.',"_",trim($hostip));

    if (array_key_exists('cdpaddress',$data[$hostip]) && is_array($data[$hostip]['cdpaddress'] )) 
      foreach ($data[$hostip]['cdpaddress'] as $i=>$cdpaddress) { 
	$cdpdeviceport=$data[$hostip]['cdpdeviceport'][$i];
	$cdpdeviceport=trim(str_replace('"',"",$cdpdeviceport));
	$cdpaddress2=str_replace('.',"_",trim($cdpaddress));
	$cdplocalifindex=$data[$hostip]['cdplocalifindex'][$i];
	$h=(float)rand( 0  , 100  )/100.0; //for hsv
	if (strlen($cdplocalifindex)) {
	    $cdpedges.= "\"host_$hostip2\" -> ".
	              "\"host_$cdpaddress2\" [fontsize=9 color=\"$h 1.000 1.000\" ".
                      " style=dashed label=\"Goes to $cdpaddress\\nat port:($cdpdeviceport)\"];\n";
	}

      }

    //iterate interface -> mac address table, skip interfaces in cdp tables (inter-switch connections)
    if (array_key_exists('ifindex2mac',$data[$hostip]) && is_array($data[$hostip]['ifindex2mac'] ))
      foreach($data[$hostip]['ifindex2mac'] as $ifindex=>$macarray) { //multiple macs per interface
	$macstr1="";
	if (in_array($ifindex,$data[$hostip]['cdplocalifindex'])) { //port connecting switches
	  continue;
	}

	//if multiple macs on a port, make the links only if target is not another known switch
	for ($e=0,$i=0;$i<count($macarray);$i++) { //iterate macs of interface
	  $mac=$macarray[$i];
	  $mac2=str_replace(' ',"_",trim($mac));
	  $h=(float)rand( 0  , 100  )/100.0; //for hsv
	  if (strlen($ifindex)) {
	    $portname=$data[$hostip]['ifindex2portname'][$ifindex];
	    $portname=str_replace('"'," ",$portname);
	    $macstr1.= "\"host_$hostip2\" -> \"host_$mac2\" [fontsize=9 color=\"$h 1.000 1.000\" label=\"From port:$portname\"];\n";
          }
	}//macs

	$macstr.= $macstr1;

      }//foreach

    $connstr.=$cdpedges;
    $connstr.=$macstr;
    #echo $cdpedges;
    #echo $macstr;
  }

  $tailstr= "}\n";


  echo "<br>Calling dot...<br>\n";
  if(($fp = fopen("x.dot",'w')) === FALSE)
    die("Failed to open x.dot for writing:$php_errormsg!");
  fwrite($fp,$headstr);
  fwrite($fp,$hoststr);
  fwrite($fp,"//end of hoststr\n");
  fwrite($fp,$hoststr2);
  fwrite($fp,"//end of hoststr2\n");
  fwrite($fp,$hoststr3);
  fwrite($fp,"//end of hoststr3\n");
  fwrite($fp,$connstr);
  fwrite($fp,$tailstr);
  fclose($fp);
  //$cmd="dot x.dot -Tpng>x.png";
  //pack unconnected nodes
  //$cmd="ccomps -x x.dot |dot|gvpack|neato -Tpng -n2 -s >x.png 2>dot.err";

  /* ******** PNG ********/
  //$cmd="ccomps -x x.dot |$graphfilter|gvpack|neato -Tpng -n2 -s >res-ntd.png 2>dot.err";
  $cmd="$graphfilter x.dot -Tpng >res-ntd.png 2>dot.err";
  file_put_contents("dot.cmd", $cmd);
  echo "Calling $cmd";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $x=trim(fgets($pfp,1024));
  if (strlen($x)) 
    echo "\nDot reports: $x\n";
  fclose($pfp);

  /* ******** SVG ********/
  $cmd="ccomps -x x.dot |$graphfilter|gvpack|neato -Tsvg -n2 -s >res-ntd.svg 2>dotsvg.err";
  echo "Calling $cmd";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $x=trim(fgets($pfp,1024));
  if (strlen($x)) 
    echo "\nDot reports: $x\n";
  fclose($pfp);
} //wantdot

?>
