<?php
/* Spiros Ioannou, sivann at gmail com, 2009-2011 */
/* NTD - network topology discovery */
/* snmpwalk must be installed (package:net-snmp-utils), also in www.net-snmp.org */

$version=0.4;

$router_ip='10.5.1.254'; //router IP
$wantbrand=1;		//find equipment brands from MAC (uses curl)
$wantlocalarp=0;	//fill and use local machine's arp table  at the end (uses arp)
$pingsubnet=0;		//ping router's subnet to populate router's arp-ip table  (2sec timeout,uses nmap)
$wantdot=1;		//enable diagramming software (dot+graphviz) (experimental)

//default gw: ip route|awk '/default/ { print $3 }'

set_time_limit(240);

header('Expires: 0');

$log="NTD Starting on ".date(DATE_RFC822)."\n";
file_put_contents("ntd.log", $log);
?>
<html>
<script language="Javascript">

function setHourglass()
{
  document.body.style.cursor = 'wait';
  return true;
}
</script>

<head>
<title>NTD - Network Topology Discovery</title>

<style>
  body {
    font-family:arial,verdana;
    font-size:11pt;
    margin:0px auto;
    text-align:center;

  }
  #content {
    margin:0px auto;
    width:800px;
    margin-top:20px;
    padding:20px;
    border:1px dashed #888888;
    background-color:#efefef;
    text-align:left;

  }
  th,td {font-size:11pt;}
  e1 {
    color:#DB4F4F;
    font-family:arial,verdana;
    font-size:18pt;
  }
  h1 {
    border-bottom:1px dotted #505050;
    color:#505050;
    font-family:arial,sans-serif;
    font-size:1.6em;
    font-weight:bold;
    height:1em;
    letter-spacing:4px;
    padding-bottom:0;
    margin-bottom:5px;

  }
  h2 {
    background-color:#25479D;
    border-bottom:1px solid #2A3753;
    color:#FFFFFF;
    font-family:arial,sans-serif;
    font-size:1.1em;
    margin-top:20px;
    margin-bottom:10px;
    padding:1px 8px;
  }
  a {
    color:blue;
    text-decoration:none;
  }
  a:hover {
    color:blue;
    text-decoration:underline;
  }

 table {
   margin:0;
   border-spacing:0;
   border-collapse:collapse;
 }
 td {
   border:1px solid black;
   padding:3px;
 }
 th {
   border:1px solid black;
   background:#E9F87E none repeat scroll 0 0;
   color:black;
   font-weight:bold;

 }
</style>

</head>
<body >
<div id='content'>

<h1>NTD - Network Topology Discovery</h1><br>
<h2>Short Info</h2>
<ul>
<li>Uses SNMP to query CDP,ARP and other tables from auto-discovered routers and switches. 
<li>Queries ieee.org for MAC&rarr;Manufacturer conversion.
<li>Creates html, text and graphical (graphviz) representation of results
<li><b>Dashed lines are links found through CDP. Other edges have random solid colors</b>
</ul>
&copy;sivann 2009-2011 v.<?=$version?><br>
<h2>Settings</h2>

<?php

//get variables as php variables
foreach($_GET as $k => $v) { if (!is_array($v)) ${$k} = trim($v);}

if (isset($graphfilter) && ($graphfilter=="0")) $wantdot=0;

if (!isset($routerip) || $routerip=="") $routerip=$router_ip;
$starthost=$routerip;

?>
<form name=form1 onsubmit="return setHourglass();">

<label for=routerip>Router IP</label>
<input type=text name="routerip" id="routerip" value="<?php $routerip;?>">
<label for=graphfilter>Graph Filter</label>
<select id=graphfilter name=graphfilter>
<option value='0'>none</option>
<option value='dot'>dot</option>
<option value='circo'>circo</option>
<option value='twopi'>twopi</option>
<option value='fdp'>fdp</option>
<input type=hidden name=action value="go">
<input type=submit value="Go" > <b>May take up several minutes to complete</b>
</form>

<?php
function dateof($filename) {
  if (file_exists($filename)) {
    clearstatcache();
    echo "<td>$filename &nbsp;</td> <td><b>" . date ("d/m/Y H:i:s", filemtime($filename))."</b>&nbsp;</td>";
  }
  else
    echo "<td>&nbsp;</td><td></td>";
}

if (!isset($action)) {
?>
<h2>Results</h2>
<table border=0>
<tr><th>Data Type</th><th>Filename</th><th>Data collected on</th></tr>
<tr><td><a target=_blank href='res-ntd.html'><b>HTML</b></a></td> <?php dateof("res-ntd.html");?></tr>
<tr><td><a target=_blank href='res-ntd.png'>PNG IMAGE</a></td> <?php dateof("res-ntd.png");?></tr>
<tr><td><a target=_blank href='res-ntd.svg'>SVG</a></td> <?php dateof("res-ntd.svg");?></tr>
<tr><td><a target=_blank href='res-ntd.txt'>TEXT</a></td> <?php dateof("res-ntd.txt");?></tr>
<tr><td><a target=_blank href='x.dot.txt'>GRAPH (DOT notation)</a></td> <?php dateof("x.dot");?></tr>
</table>

<?php


  $data=loadarr("data.ser");
  $data2=loadarr("data2.ser");
  if ($data!=0) {
    echo "These are clickable:<br>\n";
    print_r_html($data);
    print_r_html($data2);
  }

?>

</div>
</body>
</html>

<?php
  exit;
}


/*-------------*/
$brandscache[0]="";
//pretty print_r


function print_r_html($arr, $style = "display: none; margin-left: 40px;") { 
  static $i = 0; $i++;
  echo "\n<div id=\"array_tree_$i\" class='array_tree' style='font-family:lucida console,courier;font-size:8pt'>\n";

  foreach($arr as $key => $val)
  { switch (gettype($val))
    { case "array":
        echo "<a onclick=\"document.getElementById('array_tree_element_".$i."').style.display = ";
        echo "document.getElementById('array_tree_element_$i').style.display == 'block' ? 'none' : 'block';\"\n";
        echo "name=\"array_tree_link_$i\" href=\"#array_tree_link_$i\">".htmlspecialchars($key)."</a><br />\n";
        echo "<div class=\"array_tree_element_\" id=\"array_tree_element_$i\" style=\"$style\">";
        echo print_r_html($val);
        echo "</div>";
      break;
      case "integer":
        echo "".htmlspecialchars($key)." => <i>".htmlspecialchars($val)."</i><br />";
      break;
      case "double":
        echo "".htmlspecialchars($key)." => <i>".htmlspecialchars($val)."</i><br />";
      break;
      case "boolean":
        echo "".htmlspecialchars($key)." => ";
        if ($val)
        { echo "true"; }
        else
        { echo "false"; }
        echo  "<br />\n";
      break;
      case "string":
        echo "".htmlspecialchars($key)." => <code>".htmlspecialchars($val)."</code><br />";
      break;
      default:
        echo "".htmlspecialchars($key)." => ".gettype($val)."<br />";
      break; }
    echo "\n"; }
  echo "</div>\n"; 
}


function ip2fqdn($ip) {
  $cmd="host -W 1 $ip 2>host.err|grep -v 'not found'|awk '{print \$NF}'";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $host = trim(fgets($pfp, 1024)); 

  return $host;
}

//returns brand manufacturer from mac address
function brandofmac($mac) {
  $mac=strtoupper($mac);
  $mac=str_replace(':',"-",$mac);
  $mac=str_replace(' ',"-",$mac);
  $macx=explode("-",$mac);
  $qmac="{$macx[0]}-{$macx[1]}-{$macx[2]}";
  $grepmac=$macx[0].$macx[1].$macx[2];
  $cmd="curl -sd 'x=$qmac' http://standards.ieee.org/cgi-bin/ouisearch|grep $grepmac|sed 's/.*base[^)]*)//'";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $brand = trim(fgets($pfp, 4096)); 
  pclose($pfp);

  return $brand;
}


//returns brand manufacturer from mac address, with local caching
function brandofmac2($mac) {
  global $brandscache;

  $mac=strtoupper($mac);
  $mac=str_replace(':',"-",$mac);
  $mac=str_replace(' ',"-",$mac);
  $macx=explode("-",$mac);
  $qmac="{$macx[0]}-{$macx[1]}-{$macx[2]}";
  $grepmac=$macx[0].$macx[1].$macx[2];

  //read cache file
  if (file_exists("brands.tmp")) {
      $x=file_get_contents("brands.tmp");
      $brandscache = unserialize($x);
  }

  if (is_array($brandscache) && array_key_exists($qmac,$brandscache)) {
    //key found in cache file
    return $brandscache[$qmac];
  }
  //else echo "KEY $mac NOT FOUND in cache\n";

  //key not in cache file
  $cmd="curl -sd 'x=$qmac' http://standards.ieee.org/cgi-bin/ouisearch|grep $grepmac|sed 's/.*base[^)]*)//'";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  $brand = trim(fgets($pfp, 4096)); 
  pclose($pfp);

  //save new mac in cahce
  $brandscache[$qmac]=$brand;
  if(($fp = fopen("brands$lala.tmp",'w')) === FALSE)
    die("Failed to open brands.tmp for writing:$php_errormsg");
  $ser=serialize($brandscache);
  fwrite($fp,$ser);
  fclose($fp);

  return $brand;
}

function loadarr($fname) {
  if (file_exists($fname)) {
      $x=file_get_contents($fname);
      return  unserialize($x);
  }
  else {
    echo "warning: no previous $fname, found<br>\n";
    return 0;
  }
}

function savearr($arr,$fname) {
  if(($fp = fopen("$fname",'w')) === FALSE)
    die("Failed to open $fname for writing:$php_errormsg");
  $ser=serialize($arr);
  fwrite($fp,$ser);
  fclose($fp);
}



/* snmpwalk */
function sw($host, $oid, $community="snmp-com-ro") {

  if (!strlen($oid)) {
    echo "sw: called with null OID\n";exit;
  }
  if ($host=="0.0.0.0") {
    $data[0]="";
    return $data;
  }

  //return snmpwalk($host, $community, $object_id,3000); //php's own snmpwalk
  /* call snmpwalk merging multiline strings */
  $cmd="snmpwalk -t 1 -r 0 -On -v 1 -c $community  $host $oid 2>sw.err|".
       'tr \'\r\n\' \'  \'|sed -e \'s/\([.]\+1\.3\.6\)/\n\1/g\' -e \'s/$/\n/\'';

  file_put_contents("ntd.log", $cmd."\n", FILE_APPEND);
  //echo "CMD=$cmd\n";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 

  /* return lines in an array, one element per line */
  for ($i=0;!feof($pfp);$i++) {
    $x = trim(fgets($pfp, 4096)); 
    file_put_contents("ntd.log", $x."\n", FILE_APPEND);
    if (strlen($x)>1) 
      $data[$i] = chop($x);
    else $i--;
  }
  pclose($pfp);
  file_put_contents("ntd.log", "\n", FILE_APPEND);
  return $data;

}

//read snmp response lines and return only the value part
function snmpstrings($str) {
  for ($i=0;$i<count($str);$i++) {
    $x=explode(':',$str[$i],2); $x=$x[1];
    $str[$i]=$x;
  }
  return $str;
}

//query some CDP information from $host
function getcdp($host) {
  if (($host=="0.0.0.0") || $host=="") { 
    $data['cdpaddress']="0.0.0.0";
    $data['cdpdeviceid']="0.0.0.0";
    $data['cdpdeviceport']="0.0.0.0";
    $data['cdpplatform']="0.0.0.0";
    return $data; 
  }

  $cdpCacheAddress=sw($host,"1.3.6.1.4.1.9.9.23.1.2.1.1.4");//cdpCacheAddress
  for ($i=0;$i<count($cdpCacheAddress);$i++) {
    $x=explode(":",$cdpCacheAddress[$i]);
    $xx=sscanf($x[1],"%x %x %x %x");
    $ip=implode(".",$xx);
    $cdpCacheAddress[$i]=$ip;
  }

  $cdpCacheDeviceId =sw($host,"1.3.6.1.4.1.9.9.23.1.2.1.1.6");
  $cdpCacheDevicePort =sw($host,"1.3.6.1.4.1.9.9.23.1.2.1.1.7");
  $cdpCachePlatform =sw($host,"1.3.6.1.4.1.9.9.23.1.2.1.1.8");

  /*physicaldescr may be huge, so we get selected values (.1 and .1001) */
  $entPhysicalDescr_oid="1.3.6.1.2.1.47.1.1.1.1.2";
  $entPhysicalDescr =sw($host,"$entPhysicalDescr_oid");
  $data['physdescr']=snmpstrings($entPhysicalDescr);


  $data['cdpaddress']=$cdpCacheAddress;
  $data['cdpdeviceid']=snmpstrings($cdpCacheDeviceId);
  $data['cdpdeviceport']=snmpstrings($cdpCacheDevicePort);
  $data['cdpplatform']=snmpstrings($cdpCachePlatform);

  $data['cdplocalifindex']= snmp2array($cdpCacheDeviceId,$cdpCacheDeviceId,0,0,1);
  return $data;
}

//call getcdp recursively 
function getcdp_rec($host) {
  static $depth=0;
  global $data;

  $depth++;
  if ($depth==10) {
    echo "\nToo much depth in CDP recursion\n";
    exit;
  }
  $data[$host]=getcdp($host);
  for ($i=0;$i<count($data[$host]['cdpaddress']);$i++) {
    $addr=$data[$host]['cdpaddress'][$i];
    if ($host=="0.0.0.0")  //no ip management there
      continue;
    if (!strlen($addr)) 
      continue;
    if (array_key_exists($addr,$data)) 
      continue; //if already got cdp info for this ip (links are bidirectional)
    getcdp_rec($addr);
  }
  $depth--;
  if ($depth==0) 
    return $data;
}


/* helper function for sw */
function getlastpart($delimiter,$string) {
  $x=explode($delimiter,$string);
  return $x[count($x)-1];
}

//convert snmp data to table where keys correspond to snmp oid
//onlylast: return only last part of extra oid
function snmp2array ($lines,$oid,$onlylast=0,$skipkeys=0,$rcropkey=0) {
  for ($i=0;$i<count($lines);$i++) {
    $linearr=explode("=",$lines[$i]);
    $linearr[0]=trim($linearr[0]);
    //oid2:extra oid stuff appended to request oid. Used as key
    $oid2=substr($linearr[0],strpos($linearr[0],$oid)+strlen($oid)+1);
    for ($sk=0;$sk<$skipkeys;$sk++) {
      $oid2=substr($oid2,strpos($oid2,".")+1);
    }
    if ($onlylast) 
      $oid2=getlastpart(".",$oid2);

    if ($rcropkey) {
      $oidx=explode(".",$oid2);
      $x=$oidx[count($oidx)-$rcropkey-1];
      $arr[$i]=$x;
    }
    else
    {
      $x=explode(":",$linearr[1],2);
      $arr[$oid2]=trim($x[1]);
    }
  }
  return $arr;
}

/*read local arp entries*/
function pingsubnet() {
  global $ip2maclocal,$mac2iplocal;
  global $starthost;

  /* populate local arp table */
  /* you may need to modify this command */
  $cmd="nmap -n --host-timeout 2000 -sP $starthost/24";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  while (!feof($pfp)) fgets($pfp, 4096); 
  pclose($pfp);
}

function getlocalarp() {
  global $ip2maclocal,$mac2iplocal;
  global $starthost;

  /* read arp table*/
  $cmd="arp -ne|fgrep ether|awk '{print $1,$3}'";
  if ( ($pfp = popen($cmd, 'r')) === false ) 
    die("calling \"$cmd\" failed: ${php_errormsg}\n"); 
  while (!feof($pfp)) {
    $l=explode(" ",trim(fgets($pfp, 4096))); 
    if (!strlen($l[0])) continue;
    $ip2maclocal[$l[0]]=$l[1];
    $mac2iplocal[$l[1]]=$l[0];
  }
  pclose($pfp);

}

/***************************************************/
/* End of function definitions, now start quering  */
/***************************************************/

if ($pingsubnet){
  pingsubnet();
}

/* find out host connectivity */
$data=getcdp_rec($starthost);

/* read ipNetToMediaPhysAddress from router */
$ipNetToMediaPhysAddress_oid="1.3.6.1.2.1.4.22.1.2";
$ipNetToMediaPhysAddress=sw($starthost,$ipNetToMediaPhysAddress_oid);
$ip2mac= snmp2array($ipNetToMediaPhysAddress,$ipNetToMediaPhysAddress_oid,0,1);


foreach ($ip2mac as $ip=>&$mac) { 
  $mac=str_replace(':'," ",$mac);
  $m=explode(" ",$mac);
  for ($mac2="",$x=0;$x<count($m);$x++) 
    $mac2.=sprintf("%02X ",hexdec($m[$x]));
  $mac=strtoupper(trim($mac2));
  if (is_array($mac2ips[$mac]))
    array_push($mac2ips[$mac],$ip);
  else
    $mac2ips[$mac][0]=$ip;
}



/* for each host connected to our starting host get more host information and vlans */
foreach ($data as $hostip=>$hostdata) { /* foreach host */
  //if ($hostip=="0.0.0.0") continue;
  //print_r($hostdata);echo "----$hostip-------\n";

  /* get portnames */
  $ifindex2portname_oid="1.3.6.1.2.1.31.1.1.1.1";
  $ifindex2portname=sw($hostip,$ifindex2portname_oid);


  $vtpVlanState_oid="1.3.6.1.4.1.9.9.46.1.3.1.1.2";
  $vtpVlanState=sw($hostip,$vtpVlanState_oid);

  $vtpVlanName_oid="1.3.6.1.4.1.9.9.46.1.3.1.1.4";
  $vtpVlanName=sw($hostip,$vtpVlanName_oid);

  //ifindex2vlan
  $vmVlan_oid="1.3.6.1.4.1.9.9.68.1.2.2.1.2";
  $vmVlan=sw($hostip,$vmVlan_oid);

  //system description
  $sysDescr =sw($hostip,".1.3.6.1.2.1.1.1.0");
  $sysName =sw($hostip,".1.3.6.1.2.1.1.5");

  $sysServices =sw($hostip,".1.3.6.1.2.1.1.7.0");

  $data[$hostip]['ifindex2portname']= snmp2array($ifindex2portname,$ifindex2portname_oid);
  $data[$hostip]['vtpvlanstate']= snmp2array($vtpVlanState,$vtpVlanState_oid,1);
  $data[$hostip]['vtpvlanname']= snmp2array($vtpVlanName,$vtpVlanName_oid,1);
  $data[$hostip]['ifindex2vlan']= snmp2array($vmVlan,$vmVlan_oid,0);
  $data[$hostip]['sysdescr']=snmpstrings($sysDescr);
  $data[$hostip]['sysname']=snmpstrings($sysName);
  $data[$hostip]['sysservices']=snmpstrings($sysServices);

  //these are filled on the next for loop (for each vlan)
  $data[$hostip]['macs']=array();
  $data[$hostip]['mac2bridgeport']= array();
  $data[$hostip]['bridgeport2ifindex']= array();


  /* for each vlan get macs, mac2bridgeport, bridgeport2ifindex*/
  if ($data[$hostip]['sysservices'][0]<78) { //not a router
    if (array_key_exists('vtpvlanstate',$data[$hostip]) && is_array($data[$hostip]['vtpvlanstate'])) {
      foreach ($data[$hostip]['vtpvlanstate'] as $vlanid=>$state) { //foreach vlan
	if ($vlanid>1000) continue; //internal cisco vlans
	$dot1dTpFdbAddress_oid="1.3.6.1.2.1.17.4.3.1.1";
	$dot1dTpFdbAddress=sw($hostip,$dot1dTpFdbAddress_oid,"public@$vlanid");
	$t=snmp2array($dot1dTpFdbAddress,$dot1dTpFdbAddress_oid);
	if (!empty($t))
	  $data[$hostip]['macs']=  $data[$hostip]['macs']+$t;

	$dot1dTpFdbPort_oid="1.3.6.1.2.1.17.4.3.1.2";
	$dot1dTpFdbPort=sw($hostip,$dot1dTpFdbPort_oid,"public@$vlanid");
	$t=snmp2array($dot1dTpFdbPort,$dot1dTpFdbPort_oid);
	if (!empty($t))
	  $data[$hostip]['mac2bridgeport']= $data[$hostip]['mac2bridgeport']+$t;

	$dot1dBasePortIfIndex_oid="1.3.6.1.2.1.17.1.4.1.2";
	$dot1dBasePortIfIndex=sw($hostip,$dot1dBasePortIfIndex_oid,"public@$vlanid");
	$t=snmp2array($dot1dBasePortIfIndex,$dot1dBasePortIfIndex_oid,1);
	if (!empty($t))
	  $data[$hostip]['bridgeport2ifindex']= $data[$hostip]['bridgeport2ifindex']+$t;
	  //array_merge reindexes, use + instead


      } //foreach vlan
    }

    /* create the mac2portname entry in cdp from gathered info*/
    if (array_key_exists('macs',$data[$hostip])) 
    foreach ($data[$hostip]['macs'] as $decmac=>$hexmac) { //foreach mac
      $bridgeport=$data[$hostip]['mac2bridgeport'][$decmac];
      $ifindex=$data[$hostip]['bridgeport2ifindex'][$bridgeport];
      $vlan=$data[$hostip]['ifindex2vlan'][$ifindex];
      $portname=$data[$hostip]['ifindex2portname'][$ifindex];
      $data[$hostip]['mac2portname'][$hexmac]=$portname;
      $data[$hostip]['mac2vlan'][$hexmac]=$vlan;

      //an ifindex can have lots of macs
      if (is_array($data[$hostip]['ifindex2mac'][$ifindex]))
	array_push($data[$hostip]['ifindex2mac'][$ifindex],$hexmac);
      else
	$data[$hostip]['ifindex2mac'][$ifindex][0]=$hexmac;

    }//foreach mac
  }//if not router
} //foreach host


/* We've got all we could. Now create the graphs */

if ($wantdot!=0)  //wantdot
  include('ntd_dot_noports.php');


/*************************************************/
/** create non-graph result output **/

file_put_contents("res-ntd.txt", "Switch IP|VLAN|Port Name|CDP|MAC|Brand|IP|DNS|Switch Sysname\n",LOCK_EX);
file_put_contents("res-ntd.html", "<html><head><META HTTP-EQUIV='Pragma' CONTENT='no-cache'>\n",LOCK_EX);
file_put_contents("res-ntd.html", "<style>\n".
           "th{background:#0C5892;color:#ffffff; font-weight:bold;}\n".
           "th,td {font-size:11pt;}; body {font-family:arial;}\n".
           ".tr0{background-color:#93CCF7;}\n .tr1{background-color:#ffffff;}\n".
           "</style>\n".
	   "<script src='sorttable.js'></script>\n".
	   "</head>\n<body>\n",FILE_APPEND|LOCK_EX);
file_put_contents("res-ntd.html", 
            "<table class='sortable' border=0 cellspacing=2 width='100%'>\n<thead>\n".
            "<tr><th>Switch IP</th><th>VLAN</th><th>Port Name</th><th title='connected to'>CDP</th>".
	    "<th>MAC</th><th>Brand</th><th>IP</th><th>DNS</th><th>Switch Sysname</th></tr>".
            "</thead>\n<tbody>\n",FILE_APPEND|LOCK_EX);

//create the line-based db of important stuff
$count=0;
foreach ($data as $hostip=>$hostdata) { /* foreach host */
  if ($hostip=="0.0.0.0") continue;
  $sysdescr=$data[$hostip]['sysdescr'][0];
  $sysname=$data[$hostip]['sysname'][0];

  if (array_key_exists('ifindex2portname',$data[$hostip]) && is_array($data[$hostip]['ifindex2portname'] )) 
  foreach ($data[$hostip]['ifindex2portname'] as $ifindex=>$portname) {
    $vlan=$data[$hostip]['ifindex2vlan'][$ifindex];
    $macarr=$data[$hostip]['ifindex2mac'][$ifindex];

    $cdplocifind=$data[$hostip]['cdplocalifindex'];
    if (is_array($cdplocifind)) {
      $cdpindex_r=array_keys($cdplocifind,$ifindex); // array index (0,1,2,..) of local interface index
    }
    if (count($cdpindex_r)) {
      $cdpindex=$cdpindex_r[0];
      $cdpplat=$data[$hostip]['cdpplatform'][$cdpindex]; //model of remote switch
      $cdpdevport=$data[$hostip]['cdpdeviceport'][$cdpindex]; // port name of remote switch
      $cdpaddr=$data[$hostip]['cdpaddress'][$cdpindex]; //address of remote switch
      $cdpdevid=$data[$hostip]['cdpdeviceid'][$cdpindex]; //name of remote switch
      $cdpstr="Connected to: $cdpdevport <b>of</b> $cdpplat/$cdpaddr/$cdpdevid";
    }
    else 
      $cdpstr="";

    if (is_array($macarr))
    foreach ($macarr as $mac) {
      $iparr=$mac2ips[$mac];

      if (is_array($iparr))
      foreach ($iparr as $ip) {
	$count++;
	if ($count%2) 
	  $class="tr0";
	else 
	  $class="tr1";
        $fqdn=ip2fqdn($ip);
	$mac2=str_replace(' ',":",trim($mac));
	$brand=brandofmac2($mac2); //find manufacturer names from MACs

	$x="$hostip|$vlan|$portname|$cdpstr|$mac2|$brand|$ip|$fqdn|$sysname,$sysdescr\n";
	$x2="<tr class='$class'><td>$hostip</td><td>$vlan</td><td>$portname</td><td><small>$cdpstr</small></td><td>$mac2</td>".
            "<td>$brand</td><td>$ip</td><td>$fqdn</td><td><small><small><b>$sysname</b>, $sysdescr</small></small></td></tr>\n";
	file_put_contents("res-ntd.txt", $x, FILE_APPEND | LOCK_EX);
	file_put_contents("res-ntd.html", $x2, FILE_APPEND | LOCK_EX);
      }
    }
  }//ifindex loop
}
file_put_contents("res-ntd.html", "\n</tbody>\n</table>\n</body>\n</html>", FILE_APPEND | LOCK_EX);


if ($wantlocalarp){
  getlocalarp();
}

?>

<h2>New Results</h2>
<table border=0>
<tr><th>Data Type</th><th>Filename</th><th>Data collected on</th></tr>
<tr><td><a target=_blank href='res-ntd.html'><b>HTML</b></a></td> <? dateof("res-ntd.html");?></tr>
<tr><td><a target=_blank href='res-ntd.png'>PNG IMAGE</a></td> <? dateof("res-ntd.png");?></tr>
<tr><td><a target=_blank href='res-ntd.svg'>SVG</a></td> <? dateof("res-ntd.svg");?></tr>
<tr><td><a target=_blank href='res-ntd.txt'>TEXT</a></td> <? dateof("res-ntd.txt");?></tr>
<tr><td><a target=_blank href='x.dot.txt'>GRAPH (DOT notation)</a></td> <? dateof("x.dot");?></tr>
</table>
<br>
<?php

$data2['ip2mac']=$ip2mac;
$data2['mac2ips']=$mac2ips;
$data2['brandscache']=$brandscache;

if ($wantlocalarp) {
  $data2['ip2maclocal']=$ip2maclocal;
  $data2['mac2iplocal']=$mac2iplocal;
}

savearr($data,"data.ser");
savearr($data2,"data2.ser");

echo "These are clickable:<br>\n";
print_r_html($data);
print_r_html($data2);
?>


</div> <!--content-->
</body>
</html>
