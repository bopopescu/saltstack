.. pyghmi documentation master file, created by
   sphinx-quickstart on Tue Jun 18 09:15:24 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyghmi's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: ipmi.command

.. autoclass:: ipmi.command
    :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

